Hello and welcome to JavatechIG, A enthusiastic professionals technology and information group. 

javatechig-android-ui
=====================

In this series of tutorials, we show you the list of basic tutorials to get you start android programming.

1. **Android Simple List View** : This tutorial will be demonstrate to build simple and customized ListView for android.
2. **Android Toast and Custom Toast** : This sample source code below demonstrates the usages of simple and customized toast in android.
3. **Android WebView Example** : This post demonstrates the usage of WebView in android application and answers to some of the commonly asked questions with reference to android WebView. The example explains to render static HTML data or even remote URL. 
4. **Android Custom List Example**
5. **Android ViewFlipper Example**
6. **Using Custom Font Typeface in android**  
